#include "Warrior.h"

//int damageDealt;



void Warrior::displayWarriorInfo()
{
    cout << "Your Warrior details are as follows:" << endl;
    cout << "Name: " << name << " HP:" << charHp << " Strength " << strength << endl;
}
