#include<iostream>
#include <string>
#include <time.h>
#include <chrono>

using namespace std;

//Defining the node class
class Node
{
	//int data type, with ptr to next node
	int data;
	Node* next;
};

//
typedef Node* nodePtr;


void FirstElement(Node*& first, Node*& last, int number)
{
    Node* list = new Node;
    first = list;
    last = list;
};

int main()
{

    int menu = 0, n = 0, number;

    Node* first = NULL;
    Node* last = NULL;
    cout << "Amount of element in List: ";
    cin >> n;

    srand(time(NULL));

    for (int i = 0; i < n; i++)
    {
        number = (rand() % 10000 + 100);

    }
}

