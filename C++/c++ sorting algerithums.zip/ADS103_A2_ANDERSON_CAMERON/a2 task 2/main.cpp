#include <iostream>
#include <string>
#include<vector>
#include <map>
#include <list>
#include <set>

using namespace std;
int choice;
string name;
int BookCode;
bool back = false;
int BookReturnCode;
int indexOfBook = 0;

void menu();
vector<int> borrowedBooks;


//creating functions for each of the menu items
void booksOnLoan()
{

	//Print borrowedBooks vector
	cout << "Books on loan are: " << endl;

	for (int i = 0; i < borrowedBooks.size(); i++)
		cout << borrowedBooks.at(i) << ' ';
	cout << '\n';

	return menu();
}


void returnBook()
{
	cout << "What Book would you like to Return? Please use book codes" << endl;
	cin >> BookCode;


	for (int i = 0; i < borrowedBooks.size(); ++i)
	{
		if (borrowedBooks[i] == BookCode)
		{
			indexOfBook = i;
			cout << '\n';
			break;
		}
	}
	//return what book they picked
	borrowedBooks.erase(borrowedBooks.begin() + indexOfBook);
	cout << indexOfBook;

	return menu();
}

void listBooks()
{
	//Creating a list of books
	map<int, string> ListOfBooks;
	ListOfBooks.insert(make_pair(5, "Harry Potter"));
	ListOfBooks.insert(make_pair(22, "Moby Dick"));
	ListOfBooks.insert(make_pair(35, "Broken Flower Pot"));
	ListOfBooks.insert(make_pair(16, "Specky Mgee"));
	ListOfBooks.insert(make_pair(10, "Star Wars"));
	ListOfBooks.insert(make_pair(20, "Time Riders"));
	ListOfBooks.insert(make_pair(80, "Minecraft RedStone"));
	ListOfBooks.insert(make_pair(1, "God Of War Novel"));
	ListOfBooks.insert(make_pair(3, "Lord of the Rings"));
	ListOfBooks.insert(make_pair(100, "Dragon Ball Z"));
	//Printing list of books
	map<int, string>::iterator itr;
	for (itr = ListOfBooks.begin(); itr != ListOfBooks.end(); itr++)
	{
		cout << '\n';
		cout << itr->first << " " << itr->second << endl;
		cout << '\n';

	}
	return menu();
}



void borrowBook()
{

	cout << "What Book would you like to borrow? Please use book codes" << endl;
	cin >> BookCode;
	if (BookCode == 22)
	{
		borrowedBooks.push_back(22);
	}

	if (BookCode == 5)
	{
		borrowedBooks.push_back(5);
	}

	if (BookCode == 35)
	{
		borrowedBooks.push_back(35);
	}

	if (BookCode == 16)
	{
		borrowedBooks.push_back(16);
	}

	if (BookCode == 10)
	{
		borrowedBooks.push_back(10);
	}

	if (BookCode == 20)
	{
		borrowedBooks.push_back(20);
	}

	if (BookCode == 80)
	{
		borrowedBooks.push_back(80);
	}

	if (BookCode == 1)
	{
		borrowedBooks.push_back(1);
	}

	if (BookCode == 3)
	{
		borrowedBooks.push_back(3);
	}

	if (BookCode == 100)
	{
		borrowedBooks.push_back(100);
	}
	return menu();

}

void Exit()
{
	exit;
}
void menu()
{
	//Creating menu
	cout << " what would you like to do?" << endl;
	cout << "1) List all books on loan" << endl;
	cout << "2) Return a book" << endl;
	cout << "3) List all books in library" << endl;
	cout << "4) Borrow a book" << endl;
	cout << "5) Exit program" << endl;
	cout << '\n';
	cin >> choice;
	system("CLS");

	if (choice == 1)
	{
		booksOnLoan();
	}

	if (choice == 2)
	{
		returnBook();
	}

	if (choice == 3)
	{
		listBooks();
	}

	if (choice == 4)
	{
		borrowBook();
	}

	else
	{
		Exit();

	}

}

int main()
{
	cout << "Please enter user name: ";
	cin >> name;
	cout << "Welcome " << name;
	menu();
}

