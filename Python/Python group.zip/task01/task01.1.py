# Complete the following programming exercises using python programming language:
# Print first 10 numbers using while loop (e.g., 1, 2, 3, ...., 8, 9, 10)
# Print first 10 even numbers using for loop (e.g., 2, 4, 6, ...., 16, 18, 20)
# Print first 10 odd numbers using while loop (e.g., 1, 3, 5, ..., 15, 17, 19)
# Print sum of first 10 numbers using for loop
# (e.g., print the sum of 1+ 2 + 3 + ... + 8 + 9 + 10)


print("#Print first 10 numbers using while loop (e.g., 1, 2, 3, ...., 8, 9, 10)")
counter = 0  # number loop with
while counter <10:
    counter +=1  # add one we want to start at 1
    print(counter)    # print the numbers


print("\n#Print first 10 even numbers using for loop (e.g., 2, 4, 6, ...., 16, 18, 20)")
for num in range(20):    # generate a list of 20 numbers
    num +=1     # numbers start at 0 so increment by one
    if num % 2 ==0:   # test if the number is divisible by 2 it is even
        print(f"even num: {num}")  # print the even number


print("\n# Print first 10 odd numbers using while loop (e.g., 1, 3, 5, ..., 15, 17, 19)")
count = 0 # set the starting point
while count < 20:   # while loop that will stop when the count is less than 20
    count += 1   # increment the counter 
    if count % 2 != 0:      # test if current iteration of count is odd
        print(f"Odd number {count}")  # print the odd number



print("\n# Print sum of first 10 numbers using for loop")
# (e.g., print the sum of 1+ 2 + 3 + ... + 8 + 9 + 10)
numbers = range(1,11)   # range of 10 numbers 1 to 10 - excludes 11
sum = 0  # intialise the variable for sum
for num in numbers:    # for loop for 'numbers'
    sum += num         # add each number to the total
print(f"the sum of 1 to 10 is: {sum}")  # after the loop has exited print the sum of all 10 numbers



