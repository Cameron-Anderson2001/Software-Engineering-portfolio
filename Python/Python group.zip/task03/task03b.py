# -----VARIABLE-----
# setting variable "i" to "1"
i = 1

# -----LOOP-----
# creating a loop where the value in "i" is printed while the variable in "i" is under "3"
while i < 3:
    print(i)
# increments the value in "i" by "1"
    i = i + 1

# -----CONDITIONAL-----
# when the value in "i" is over "2" print "0"
else:
    print(0)

# -----RESULT-----
# the expected outcome
# of this program was
# that the value in "i"
# would be printed twice
# as "2" is under "3" but
# as "3" equals "3" the
# "else" would activate
# printing "0".
