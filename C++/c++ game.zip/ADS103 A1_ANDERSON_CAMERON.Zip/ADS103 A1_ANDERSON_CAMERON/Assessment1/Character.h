#pragma once
#include <iostream>
#include <string>

using namespace std;


class Character
{

protected:
	string name;
	



public:
	Character();
	Character(string _name, int _charHp);
	int charHp;
	int strength;
	int defence;
	
	
	
	//Functions
	void doAction();
	void takeDamage(int damageTaken);
	bool isAlive();
	int deltDamage(int damagedealt);

	//Setters
	string getname();
	void setName(string _name);
	void displayInfo();


};

