#include "Character.h"
#include<time.h>
#include <stdlib.h>



//Setting default character info
Character::Character()
{
	name = "Hermione";
	charHp = 100;
	defence = rand() % 100 + 1;
	strength = rand() % 100 + 1;
}

Character::Character(string _name, int _charHp)
{
	name = _name;
	charHp = _charHp;
}

//deltDamage is a random amount of damage between 1-100
int Character::deltDamage(int damagedealt)
{
	srand(time(0));

	//int damagedealt;
	damagedealt = rand() % 100;

	cout << name << " is doing " << damagedealt << " damage." << endl;

	charHp - damagedealt;
	
	return damagedealt;
}

void Character::doAction()
{
	//deltDamage();
	
}

void Character::takeDamage(int damageTaken)
{
	//Is the damage taken giving a random number from 1-100
	srand(time(0));

	
	damageTaken = deltDamage(damageTaken);

	int newCharhp;
	newCharhp = charHp - damageTaken; 

	cout << "You've been hit! Damage taken " << damageTaken << " You have " << newCharhp << " HP. Be careful!" << endl;

	charHp = newCharhp;
	

}

bool Character::isAlive()
{
	if (charHp <= 0 )
	{
		return false;
		cout << "You are dead!" << endl;
	}
	else;
	return true;
}



string Character::getname()
{
	return string();
}

void Character::setName(string _name)
{
	if (_name.length() > 0)
		name = _name;

	else
		cout << "Please enter valid character name!" << endl;
}




void Character::displayInfo()
{

	cout << "Name: " << name << " ,HP:" << charHp << " Strength: " << strength << endl;
}
