#Write a python program that ask for an integer input from the user and prints its multiplications
#on the screen. The program should follow these steps:
#Print on the screen, prompting for an input number from the user (e.g., ‘Enter an integer value’)
#Print the multiplication tables of a given number for 10 times

#Asking for int
number = int(input("Please enter a number: "))

#Collecting the number, and multiplying it
for count in range(1, 11): #starts at 1, however must be 11, because it finishes
#one before what is said      
    # getting the number you put in, then adding x for *
    #count is counting the line
   print (number, 'x', count, '=', number * count)    #As aquired from https://www.javatpoint.com/python-display-multiplication-table
