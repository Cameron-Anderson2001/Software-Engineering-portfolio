# for i in range (1,10):
#     print (i,i*i)
    
#running same loop, however with a while instead of a for  
i=0 #starting i at 0
while i<9: #while is greater than 9
     i=i+1 
     print (i,i*i) #printing i, next to i x i