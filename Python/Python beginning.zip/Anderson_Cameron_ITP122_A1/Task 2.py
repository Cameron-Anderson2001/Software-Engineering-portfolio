#task 2

#Does the addition print in whole numbers
print(4 + 2)

#Prints the same thing as a decimal, like a float int
print (4 + 2.0)

#Correctly minuses decimals so it makes a negative number
print( 3.5 - 4.0)

#Correctly mulitplies whole numbers
print( 5 * 7)

#Creates a correct decimal number by dividing
print(23 / 4)

#Gives same answer as above
print(23 / 4.0)

#Am slightly confused by this, however, it seems like it should be the remainder
#after dividing the first number by the second
print(23 % 4)

#** is the power of (also known as the exponant), so this is saying 3 to the power
# of 2, also known as 3^2
print(3**2)

#Gives 9^0.5
print(9**0.5)