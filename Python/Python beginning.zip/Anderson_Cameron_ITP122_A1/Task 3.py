#Task 3

print("Baby baby" '\n')
print('\t' '\t' "Yes Mama," '\n')
print("Eating a Sugar," '\n')
print('\t' '\t' " No Mama" '\n')
print("Telling a lie," '\n')
print('\t' '\t' " No Mama" '\n')
print("Open your mouth," '\n')
print('\t' '\t' " Ha Ha Ha!" '\n')