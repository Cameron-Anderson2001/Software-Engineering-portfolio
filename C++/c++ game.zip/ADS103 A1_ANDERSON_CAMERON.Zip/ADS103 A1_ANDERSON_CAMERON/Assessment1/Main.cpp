#include <iostream>
#include <string>
#include "Character.h"
#include "Warrior.h"
#include "Mage.h"
#include "Paladin.h"
#include <time.h>
#include <stdlib.h>

using namespace std;

int damageDealt;
string name;
int damageTaken;
string warriorName;
string mageName;
string paladinName;
char lvlUp;
bool choice;
bool PaladinLvl;


void main()
{
	srand(time(NULL));
	//Asking for a name input
	cout << "What is thy main name?" << endl;
	cin >> name;
	cout << "\n\n";

	//first character
	Character c1;
	c1.setName(name);
	c1.strength;
	c1.displayInfo();
	cout << "\n\n";
	
	//Creating the mage class, using the name from the first character
	Mage m1;
	m1.setName(name);
	m1.manaPoints;
	m1.displayMageInfo();
	cout << "\n\n";
	
	Paladin p1;
	p1.setName(name);
	p1.healing();
	p1.displayPaladinInfo();
	cout << "\n\n";

	//Creating a do while loop for the paladin and mage to attack eachother
	do {
		p1.PaladinDoAction();
		m1.takeDamage(damageDealt);
		m1.Fireball();
		p1.takeDamage(damageDealt);
		//Loop ends when one of the characters has hp of less than 0
	} while (m1.isAlive() || p1.isAlive());
	cout << "Paladin HP = " << p1.charHp << endl;
	cout<<"Mage HP = "<<m1.charHp<<endl;





}