#pragma once
#include"Warrior.h"
#include "Character.h"




class Paladin : public Warrior
{



public:
	int healAmount;

	void healing() {

		if (charHp > 30)
		{
			healAmount * 3;
			ragePoints - 4;

		}

		else;
		ragePoints + 1;

	}

	void PaladinDoAction() {

		heavySwing();
		healing();
	}

	int paladinHp = charHp;
	void displayPaladinInfo();

};

