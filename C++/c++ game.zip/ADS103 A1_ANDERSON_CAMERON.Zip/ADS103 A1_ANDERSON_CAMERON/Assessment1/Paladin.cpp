#include "Paladin.h"
#include "character.h"




////void Paladin::displayPaladinInfo()
//{
//    cout << "Your Warrior details are as follows:" << endl;
//    cout << "Name: " << name << " HP:" << charHp << " Strength " << strength << endl;
//}

void Paladin::displayPaladinInfo()
{
	cout << "Your Paladin details are as follows:" << endl;
	   cout << "Name: " << name << " HP:" << charHp << " Rage Points " << ragePoints << endl;
}
