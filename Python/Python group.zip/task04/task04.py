# **Task 4: Loop programming for a simple case project**
# You are hired as a software coder for Movies4Us Pty Ltd located in Melbourne, Australia. 
# Your task is to develop a software program that issues 200 movie tickets. 
# Your software program is to print “welcome to Movie4Us” to the first 200 users 
# but write “there is no more ticket” to the 201th user.
# The software also needs to display how many tickets are available to each customer.
# For example, if Tim is 50th user to buy the movie ticket, your software program should display “You
# are the 50th user. The number of remaining tickets is now 150”. Prepare software code with
# sufficient comments to explain the progress.
tickets = range(1,201)  # define a range of 200 numbers   1 to 201(exclusive)

for ticketNum in tickets:                            # loop through the tickets one at a time
    print(f"welcome to Movies4US")                   # display welcome message
    print(f"you are the {ticketNum} user ")          # display the current ticket being sold
    #print("type of ticketNum: ", type(ticketNum))   # debugging to determine type result = int
    #print("type of 'tickets': ", type(tickets))     # debugging to determine type result = range
    remainingTickets = len(tickets) - ticketNum      # how many tickets left - subtract the sold tickets
                                                     # from the available tickets.
    print(f"The number of remaining tickets is now {remainingTickets}")   # display the remaining tickets.
print("There are no more tickets")                   # display to the 201st user that there are no more tickets