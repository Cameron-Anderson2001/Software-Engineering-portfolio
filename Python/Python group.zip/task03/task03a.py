# -----VARIABLE-----
# setting variable "b" to "10"
b = 10

# -----LOOP-----
# creating a loop where "Hello" is printed while the value in "b" is under "10"
while b < 10:
    print("Hello")
# increments the value in "b" by "1"
    b +=1

# -----RESULT-----
# the expected outcome
# of this program was
# that "Hello" would
# not be printed as
# "b" is already equal
# to "10".
