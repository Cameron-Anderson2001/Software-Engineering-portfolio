#pragma once
#include"Character.h"




class Mage : public Character
{
public:
    Mage();

    int fireballDmg;
    int damagedealt;


    int mageHp = charHp;
    int manaPoints;

    void Fireball() {

        //srand(time(0));


        //manaPoints = rand() % 100;

        if (manaPoints > 10)
        {
            cout << "You used fireball. You're damage is " << deltDamage(damagedealt) << endl;
        }
        else
            cout << "You dont have enough mana!" << endl;

        



    };
    void displayMageInfo();
};