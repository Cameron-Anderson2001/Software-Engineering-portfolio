# ITP122_A2

**Task 1: Coding for simple loops**
1. Complete the following programming exercises using python programming language:
• Print first 10 numbers using while loop (e.g., 1, 2, 3, ...., 8, 9, 10)
• Print first 10 even numbers using for loop (e.g., 2, 4, 6, ...., 16, 18, 20)
• Print first 10 odd numbers using while loop (e.g., 1, 3, 5, ..., 15, 17, 19)
• Print sum of first 10 numbers using for loop
(e.g., print the sum of 1+ 2 + 3 + ... + 8 + 9 + 10).
2. Write a python program that ask for an integer input from the user and prints its multiplications
on the screen. The program should follow these steps:
Print on the screen, prompting for an input number from the user (e.g., ‘Enter an integer value’)
Print the multiplication tables of a given number for 10 times
An example of the program output when a user enters 5:
5 x 1 = 5
5 x 2 = 10
5 x 3 = 15
5 x 4 = 20
5 x 5 = 25
5 x 6 = 30
5 x 7 = 35
5 x 8 = 40
5 x 9 = 45
5 x 10 = 50


**Task 2: Coding for different types of loops**
Convert the following for loops into the equivalent while loop:
a)
Run the program. Include a screenshot of the output on the screen in your zip file.
b)
Run the program. Include a screenshot of the output on the screen in your zip file.

**Task 3: Interpretation of loop codes**
a) b=10
While (b<10)
Print (“Hello”)
b+=1
Explain the code with comments and write down the expected output
b) i=1
while i<3:
print(i)
i=i+1
else:
print(0)
Explain the code with comments and write down the expected output.

**Task 4: Loop programming for a simple case project**
You are hired as a software coder for Movies4Us Pty Ltd located in Melbourne, Australia. Your task is
to develop a software program that issues 200 movie tickets. Your software program is to print
“welcome to Movie4Us” to the first 200 users but write “there is no more ticket” to the 201th user.
The software also needs to display how many tickets are available to each customer.
For example, if Tim is 50th user to buy the movie ticket, your software program should display “You
are the 50th user. The number of remaining tickets is now 150”. Prepare software code with
sufficient comments to explain the progress.
