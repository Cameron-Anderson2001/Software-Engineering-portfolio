# sum = 0
# for i in range (10,0,-1):   # loop 10 to 0 in increment of -1
#     sum = sum+i
#     print(i,sum)

sum = 0     #Creates the sum of 0
loops = 11      #starts the loop at 10
while True:     #While the loop is true, it loops forever
    loops -= 1    # decrement by 1
    sum = sum + loops #declaring sum is sum + how many loops
    #loops += -1      # alternate way to decrement
    print(loops, sum) #Prints the loops first, then the sum 
    if loops == 1:  
        break   #Breaking when the loop finishes at 1
        


