#Task 4, Loseweightnow coding
print("Welcome to LostWeightNow Pty Ltd.")

#collecting all data to print
firstName= input("Please enter first name: ")
lastName = input("And your last name: ")
age = input("What is your age? ")
bodyWeight = float(input("What is your weight (in Kg) "))
bodyHeight = float(input("And what is your height (in cm) "))
BMI = {bodyWeight / (bodyHeight/100)**2}

#Now printing all of the previous data
print("Welcome "+ firstName + " " + lastName + " You are " + age + " years old.You have a BMI of" + str(BMI))

#Getting program to have an input before closing
stop = input()