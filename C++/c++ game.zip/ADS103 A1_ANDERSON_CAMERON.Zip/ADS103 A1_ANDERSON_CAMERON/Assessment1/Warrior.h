#pragma once
#include"Character.h"

using namespace std;


				//Inherited from character.h
class Warrior : public Character
{
public:
	int swingDamage;
	int ragePoints = rand() % 100;
	int damageDealt = rand() % 100;



	void heavySwing() {
		if (ragePoints > 15)
		{
			deltDamage(damageDealt)* strength;
			ragePoints + 5;
		}
		//else;
		//cout << "You missed" << endl;
	}
	void displayWarriorInfo();
};
