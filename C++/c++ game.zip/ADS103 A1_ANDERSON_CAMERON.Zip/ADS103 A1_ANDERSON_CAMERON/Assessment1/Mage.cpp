#include "Mage.h"

Mage::Mage() : Character()
{
    manaPoints = this->strength;
}

void Mage::displayMageInfo()
{
    cout << "Your mage details are as follows:" << endl;
    cout << "Name: " << name << " HP:" << charHp << " Mana: " << manaPoints << endl;
}
