#include <iostream>
#include<string>
#include <fstream>
#include<vector>
#include <chrono>
#include<chrono>
using namespace std;
typedef chrono::high_resolution_clock Clock;

void bubbleSort()
{
	auto start_time = Clock::now();

	ifstream file;
	file.open("a2_task1_input1.txt", ifstream::in);

	//uncomment when going for second file
	//file.open("a2_task1_input2.txt", ifstream::in);
	if (!file.is_open())
	{
		cout << "file not opened" << endl;
	}

	int numberOfElements;
	file >> numberOfElements;
	vector<int>elements;
	//int* elements = (int*)malloc(numberOfElements * sizeof(int));

	int element;
	int index = 0;
	while (file >> element)
	{
		elements.push_back(element);
	}

	bool didDoSwap = false;
	do
	{
		didDoSwap = false;
		for (int index = 0; index < elements.size() - 1; ++index)
		{
			int element = elements[index];
			int nextElement = elements[index + 1];

			if (element > nextElement)
			{
				elements[index] = nextElement;
				elements[index + 1] = element;
				didDoSwap = true;
			}
		}

	} while (didDoSwap);
	auto end_time = Clock::now();
	cout << "Time to sort 5000 numbers:"
		<< chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << endl;
}

void otherSort()
{
	auto start_time = Clock::now();
	ifstream file;
	file.open("a2_task1_input1.txt", ifstream::in);

	//Uncoment when going for second file
	//file.open("a2_task1_input2.txt", ifstream::in);
	if (!file.is_open())
	{
		cout << "file not opened" << endl;
	}

	int numberOfElements;
	file >> numberOfElements;
	vector<int>elements;

	int element;
	int index = 0;
	while (file >> element)
	{
		elements.push_back(element);

	}




	auto end_time = Clock::now();
	cout << "Time to sort 5000 numbers:"
		<< chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << endl;
}
int main(void)
{
	bubbleSort();




}

